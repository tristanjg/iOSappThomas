//
//  ViewController.swift
//  iOSapp
//
//  Created by Tristan Gardenhire on 10/1/18.
//  Copyright © 2018 Thomas Auto Group. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, UITextViewDelegate {
    
    @IBOutlet weak var serviceWebview: WKWebView!
    
    @IBOutlet weak var specialsWebview: WKWebView!
    
    @IBOutlet weak var newInvWebview: WKWebView!
    
    @IBOutlet weak var usedInvWebview: WKWebView!
    
    @IBOutlet weak var tradeinWebview: WKWebView!
    
    @IBOutlet weak var reviewWebview: WKWebView!
    
    @IBOutlet weak var policyWebview: WKWebView!
    
    @IBOutlet weak var leadingCon: NSLayoutConstraint!
    
    @IBOutlet weak var sideBar: UIView!
    
    @IBOutlet weak var manualsWebview: WKWebView!
    
    @IBOutlet weak var staffWebview: WKWebView!
    
    @IBOutlet weak var howtoWebview: WKWebView!
    
    @IBOutlet weak var bluetoothWebview: WKWebView!
    
    @IBOutlet weak var carLoanAmount: UITextField!
    
    @IBOutlet weak var months: UITextField!
    
    @IBOutlet weak var salesTax: UITextField!
    
    @IBOutlet weak var annualPercentageRate: UITextField!
    
    @IBOutlet weak var resultOne: UILabel!
    
    @IBOutlet weak var resultTwo: UILabel!
    
    @IBAction func calculateLoan(_ sender: Any) {
        let cla = (carLoanAmount.text as! NSString).floatValue
        let mon = (months.text as! NSString).floatValue
        let st = (salesTax.text as! NSString).floatValue
        let apr = (annualPercentageRate.text as! NSString).floatValue
        let claOther = 1 + st / 100
        let claNew = cla * claOther
        let monthlyRate = apr / 12
        let monthlyRateNew = monthlyRate / 100
        let a = 1 + monthlyRateNew
        let b = powf(a, -mon)
        let den = 1 - b
        let num = monthlyRateNew * claNew
        let monthlyPayment = num / den
        resultOne.text = "\(claNew)"
        resultTwo.text = "\(monthlyPayment)"
    }
    
    
    
    
    var menuShowing = false

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urlService = URL(string: "https://www.romeovilletoyota.com/service-center-schedule-service/")
        let requestService = URLRequest(url: urlService!)
        serviceWebview?.load(requestService)
        
        let urlSpecials = URL(string: "https://www.romeovilletoyota.com/search/special/tp/")
        let requestSpecials = URLRequest(url: urlSpecials!)
        specialsWebview?.load(requestSpecials)
        
        let urlNewInv = URL(string: "https://www.romeovilletoyota.com/search/new/tp/s:yr1/")
        let requestNewInv = URLRequest(url: urlNewInv!)
        newInvWebview?.load(requestNewInv)
        
        let urlUsedInv = URL(string: "https://www.romeovilletoyota.com/search/used/tp/v:3/")
        let requestUsedInv = URLRequest(url: urlUsedInv!)
        usedInvWebview?.load(requestUsedInv)
        
        let urlTradein = URL(string: "https://www.romeovilletoyota.com/appraise-trade/")
        let requestTradein = URLRequest(url: urlTradein!)
        tradeinWebview?.load(requestTradein)
        
        let urlReview = URL(string: "https://search.google.com/local/writereview?placeid=ChIJu9254StZDogR7RHR49RmnDo")
        let requestReview = URLRequest(url: urlReview!)
        reviewWebview?.load(requestReview)
        
        let urlManuals = URL(string: "https://www.toyota.com/owners/resources/owners-manuals")
        let requestManuals = URLRequest(url: urlManuals!)
        manualsWebview?.load(requestManuals)
        
        let urlStaff = URL(string: "https://www.romeovilletoyota.com/meet-our-staff/")
        let requestStaff = URLRequest(url: urlStaff!)
        staffWebview?.load(requestStaff)
        
        let urlHowto = URL(string: "https://www.toyota.com/owners/how-to-videos")
        let requestHowto = URLRequest(url: urlHowto!)
        howtoWebview?.load(requestHowto)
        
        let urlBluetooth = URL(string: "https://www.toyota.com/connect/")
        let requestBluetooth = URLRequest(url: urlBluetooth!)
        bluetoothWebview?.load(requestBluetooth)
        
        let urlPolicy = URL(string: "https://www.romeovilletoyota.com/privacy-policy/")
        let requestPolicy = URLRequest(url: urlPolicy!)
        policyWebview?.load(requestPolicy)
        
        
        sideBar?.layer.shadowOpacity = 1
        sideBar?.layer.shadowRadius = 6
        
        
        view.setGradientBackground(colorOne: Colors.red, colorTwo: Colors.black)
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func onCallusClick(_ sender: Any) {
        let url:NSURL = NSURL(string: "tel://8157442760")!
        UIApplication.shared.open(url as URL)
    }
    
    @IBAction func sideMenu(_ sender: Any) {
        
        if (menuShowing) {
            leadingCon.constant = -215
        } else {
            leadingCon.constant = 0
            
            UIView.animate(withDuration: 0.3, animations: {
                self.view.layoutIfNeeded()
            })
        }
        
        menuShowing = !menuShowing
    }
    
}

